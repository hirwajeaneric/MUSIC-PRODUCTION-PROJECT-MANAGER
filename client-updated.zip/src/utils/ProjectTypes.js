export const ProjectTypes = [
    "Audio",
    "Video",
    "Audio and video",
];