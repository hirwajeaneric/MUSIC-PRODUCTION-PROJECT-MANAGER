export const measurementUnits = [
    "Piece(s)",
    "Personnel(s)",
];